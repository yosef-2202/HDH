from flask import Flask, render_template, request, jsonify, Response
from models.behavior_analyzer import BehaviorAnalyzer
from models.chatbot_manager import ChatbotManager
from models.system_settings import SystemSettings
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

settings = SystemSettings()
analyzer = BehaviorAnalyzer(settings)
chatbot = ChatbotManager(settings)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/settings', methods=['GET', 'POST'])
def handle_settings():
    if request.method == 'POST':
        data = request.json
        settings.update_settings(data)
        return jsonify({"status": "success", "message": "Cập nhật thành công!"})
    return jsonify(settings.get_settings())

@app.route('/api/chat', methods=['POST'])
def chat():
    user_msg = request.json.get('message')
    response = chatbot.get_response(user_msg)
    return jsonify({"response": response, "enabled": settings.chatbot_enabled})

@app.route('/upload_video', methods=['POST'])
def upload_video():
    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "Không có file"}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "Chưa chọn file"}), 400
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        return jsonify({"status": "success", "filepath": filepath})

@app.route('/video_feed')
def video_feed():
    src_type = request.args.get('type', 'webcam')
    source = request.args.get('source', '0')
    if src_type == 'webcam':
        source = 0
    return Response(analyzer.generate_frames(source), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/latest_data')
def latest_data():
    return jsonify({
        "data": analyzer.latest_data,
        "stats": analyzer.stats
    })

if __name__ == '__main__':
    app.run(debug=True, threaded=True, host='0.0.0.0')
